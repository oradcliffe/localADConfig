﻿configuration fileShareConfig
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xDFS, xPendingReboot, xSMBShare, cNtfsAccessControl
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {

    $publicDirPath = "$env:SystemDrive\shares\Public"
    $privateDirPath = "$env:SystemDrive\shares\Private"
    $RootOUs = ('IT', 'Marketing', 'Accounting')
    $itGroupName = 'G_IT'
    $groupNamePrefix = 'G_'

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        File publicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = $publicDirPath
        }

        File privateDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = $privateDirPath
        }

        foreach ($RootOU in $RootOUs) {
            File "groupDir_$RootOU"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$privateDirPath\$RootOU"
            }
        }

        xComputer JoinDomain 
        { 
            Name = $env:ComputerName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        cNtfsPermissionEntry publicDir_FullControl
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir',
                        '[xPendingReboot]Reboot1'
        }

        cNtfsPermissionEntry publicDir_Modify
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = 'Domain Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'Modify'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir',
                        '[xPendingReboot]Reboot1'
        }

        cNtfsPermissionEntry privateDir_FullControl
        {
            Ensure = 'Present'
            Path = $privateDirPath
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]privateDir',
                        '[xPendingReboot]Reboot1'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                cNtfsPermissionEntry "groupDir_FullControl_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$privateDirPath\$RootOU"
                        Principal = $itGroupName
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU",
                                    '[xPendingReboot]Reboot1'
                    }
            }
            else {
                cNtfsPermissionEntry "groupDir_Modify_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$privateDirPath\$RootOU"
                        Principal = "$groupNamePrefix$RootOU"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'Modify'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU",
                                    '[xPendingReboot]Reboot1'
                    }
            }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = $publicDirPath  
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]publicDir',
                        '[xPendingReboot]Reboot1'
        }

        xSmbShare Private
        {
            Ensure = 'Present'
            Name   = 'Private'
            Path = $privateDirPath  
            FullAccess = "$domainName\$itGroupName"
            Description = 'This is a private share'
            DependsOn = '[File]privateDir',
                        '[xPendingReboot]Reboot1'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                    xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private\$RootOU"
                    Path = "$privateDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU",
                                '[xPendingReboot]Reboot1'
                }
            }
            else {
                xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private\$RootOU"
                    Path = "$privateDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$RootOU"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU",
                                '[xPendingReboot]Reboot1'
                }
            }
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }
        
        ###Create Namespaces###

        xDFSNamespaceServerConfiguration DFSNamespaceConfig
        {
            IsSingleInstance          = 'Yes'
            UseFQDN                   = $false
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_ServerA
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\servera\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_ServerB
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\serverb\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Private_ServerA
        {
            Path                 = "\\$DomainName\Private"
            TargetPath           = '\\servera\Private'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Private folder for company groups'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Private'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Private_ServerB
        {
            Path                 = "\\$DomainName\Private"
            TargetPath           = '\\serverb\Private'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Private folder for company groups'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Private'
        }

        ForEach ($RootOU in $RootOUs) {
            xDFSNamespaceRoot "DFSNamespaceRoot_Private_ServerA_$RootOU"
            {
                Path                 = "\\$DomainName\Private\$RootOU"
                TargetPath           = "\\servera\Private\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerA',
                            "[xSMBShare]Private_$RootOU"
            }

            xDFSNamespaceRoot "DFSNamespaceRoot_Private_ServerB_$RootOU"
            {
                Path                 = "\\$DomainName\Private\$RootOU"
                TargetPath           = "\\serverb\Private\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerB',
                            "[xSMBShare]Private_$RootOU"
            }
        }
        

        ###Start DFS Replication configuration###

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = 'servera', 'serverb'
            Folders = 'Public'
            Topology = 'Fullmesh'
            ContentPaths = $publicDirPath
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_ServerA',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_ServerB'
        }

        xDFSReplicationGroup PrivateReplication
        {
            GroupName = 'PrivateFiles'
            Description = 'Private folder to hold group folders'
            Ensure = 'Present'
            Members = 'servera', 'serverb'
            Folders = 'Private'
            Topology = 'Fullmesh'
            ContentPaths = $privateDirPath
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerA',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerB'
        }

        ForEach ($RootOU in $RootOUs) {        
        xDFSReplicationGroup "PrivateReplication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = 'servera', 'serverb'
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "$privateDirPath\$RootOU"
                DomainName = $DomainName
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerA_$RootOU",
                            "[xDFSNamespaceRoot]DFSNamespaceRoot_Private_ServerB_$RootOU"
            }
        }
        
    }
}

$cd = @{
    AllNodes = @(
        @{
            NodeName = 'localhost'
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
    )
}