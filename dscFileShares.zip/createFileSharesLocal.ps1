﻿configuration sharedDirConfig
{ 
   param 
   () 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xSMBShare

    Node localhost
    {

    $RootOUs = ('IT', 'Marketing', 'Accounting')
    $itGroupName = 'G_IT'
    $groupNamePrefix = 'G_'

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true
        }

        File PublicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = "$env:SystemDrive\shares\Public"
        }

        File PrivateDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = "$env:SystemDrive\shares\Private"
        }

        foreach ($RootOU in $RootOUs) {
            File "GroupDir_$RootOU"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$env:SystemDrive\shares\Private\$RootOU"
            }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = "$env:SystemDrive\shares\Public"  
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]Publicdir'
        }

        xSmbShare Private
        {
            Ensure = 'Present'
            Name   = 'Private'
            Path = "$env:SystemDrive\shares\Private"  
            FullAccess = "$domainName\$itGroupName"
            Description = 'This is a private share'
            DependsOn = '[File]Privatedir'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                    xSmbShare "Private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private_$RootOU"
                    Path = "$env:SystemDrive\shares\Private\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]Groupdir_$RootOU"
                }
            }
            else {
                xSmbShare "Private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private_$RootOU"
                    Path = "$env:SystemDrive\shares\Private\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$RootOU"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]Groupdir_$RootOU"
                }
            }
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }
    }
}