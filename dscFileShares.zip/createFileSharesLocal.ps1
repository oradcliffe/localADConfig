﻿configuration sharedDirConfig
{ 
   param 
   () 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xSMBShare, cNtfsAccessControl

    Node localhost
    {

    $publicDirPath = "$env:SystemDrive\shares\Public"
    $privateDirPath = "$env:SystemDrive\shares\Private"
    $RootOUs = ('IT', 'Marketing', 'Accounting')
    $itGroupName = 'G_IT'
    $groupNamePrefix = 'G_'

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true
        }

        File publicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = $publicDirPath
        }

        File privateDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = $privateDirPath
        }

        foreach ($RootOU in $RootOUs) {
            File "groupDir_$RootOU"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$privateDirPath\$RootOU"
            }
        }

        cNtfsPermissionEntry publicDir_FullControl
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        cNtfsPermissionEntry publicDir_ReadAndExecute
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = 'Domain Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'Modify'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        cNtfsPermissionEntry privateDir_FullControl
        {
            Ensure = 'Present'
            Path = $privateDirPath
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]privateDir'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                cNtfsPermissionEntry "groupDir_FullControl_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$privateDirPath\$RootOU"
                        Principal = $itGroupName
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
            }
            else {
                cNtfsPermissionEntry "groupDir_ReadAndExecute_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$privateDirPath\$RootOU"
                        Principal = "$groupNamePrefix$RootOU"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'Modify'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
            }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = $publicDirPath  
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]publicDir'
        }

        xSmbShare Private
        {
            Ensure = 'Present'
            Name   = 'Private'
            Path = $privateDirPath  
            FullAccess = "$domainName\$itGroupName"
            Description = 'This is a private share'
            DependsOn = '[File]privateDir'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                    xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private\$RootOU"
                    Path = "$privateDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
            else {
                xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "Private\$RootOU"
                    Path = "$privateDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$RootOU"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }
    }
}