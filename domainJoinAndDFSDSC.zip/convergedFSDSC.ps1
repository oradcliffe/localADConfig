﻿configuration fileShareConfig
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds

    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xComputerManagement, xDFS, xPendingReboot, xSMBShare, cNtfsAccessControl
    [System.Management.Automation.PSCredential ]$domainCreds = New-Object System.Management.Automation.PSCredential ("${domainName}\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost
    {

    $publicDirPath = "$env:SystemDrive\shares\Public"
    $rootDirPath = "$env:SystemDrive\shares"
    $RootOUs = ('IT', 'Marketing', 'Accounting')
    $itGroupName = 'G_IT'
    $groupNamePrefix = 'G_'

        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyAndAutoCorrect'            
            RebootNodeIfNeeded = $true            
        }

        File publicDir
        {
            Type = 'Directory'
            Ensure = 'Present'
            DestinationPath = $publicDirPath
        }

        foreach ($RootOU in $RootOUs) {
            File "groupDir_$RootOU"
            {
                Type = 'Directory'
                Ensure = 'Present'
                DestinationPath = "$rootDirPath\$RootOU"
            }
        }

        xComputer JoinDomain 
        { 
            Name = $env:ComputerName
            DomainName = $domainName
            Credential = $domainCreds
        }

        xPendingReboot Reboot1
        { 
            Name = 'RebootServer'
            DependsOn = '[xComputer]JoinDomain'
        }

        cNtfsPermissionEntry publicDir_FullControl
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = $itGroupName
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        cNtfsPermissionEntry publicDir_Modify
        {
            Ensure = 'Present'
            Path = $publicDirPath
            Principal = 'Domain Users'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'Modify'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
            DependsOn = '[File]publicDir'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                cNtfsPermissionEntry "groupDir_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = $itGroupName
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
            }
            else {
                cNtfsPermissionEntry "groupDir_Modify_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = "$groupNamePrefix$RootOU"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'Modify'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
                cNtfsPermissionEntry "groupDir_fullControl_$RootOU"
                    {
                        Ensure = 'Present'
                        Path = "$rootDirPath\$RootOU"
                        Principal = "$itGroupName"
                        AccessControlInformation = @(
                            cNtfsAccessControlInformation
                            {
                                AccessControlType = 'Allow'
                                FileSystemRights = 'FullControl'
                                Inheritance = 'ThisFolderSubfoldersAndFiles'
                                NoPropagateInherit = $false
                            }
                        )
                        DependsOn = "[File]groupDir_$RootOU"
                    }
            }
        }

        xSmbShare Public
        {
            Ensure = 'Present'
            Name   = 'Public'
            Path = $publicDirPath  
            FullAccess = "$domainName\$itGroupName"
            ChangeAccess = "$domainName\Domain Users"
            Description = "This is a public share"
            DependsOn = '[File]publicDir'
        }

        foreach ($RootOU in $RootOUs) {
            if ($RootOU -eq 'IT'){
                    xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "$RootOU"
                    Path = "$rootDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
            else {
                xSmbShare "private_$RootOU"
                {
                    Ensure = 'Present'
                    Name   = "$RootOU"
                    Path = "$rootDirPath\$RootOU"  
                    FullAccess = "$domainName\$itGroupName"
                    ChangeAccess = "$domainName\$groupNamePrefix$RootOU"
                    Description = "This is a private share for $RootOU"
                    DependsOn = "[File]groupDir_$RootOU"
                }
            }
        }

        WindowsFeature DFSNamespace
        {
            Name = 'FS-DFS-Namespace'
            Ensure = 'Present'
        }

        WindowsFeature DFSReplication
        {
            Name = 'FS-DFS-Replication'
            Ensure = 'Present'
        }

        WindowsFeature RSATDFSMgmtConInstall
        {
            Ensure = 'Present'
            Name = 'RSAT-DFS-Mgmt-Con'
        }
          
        ###Create Namespaces###

        xDFSNamespaceServerConfiguration DFSNamespaceConfig
        {
            IsSingleInstance          = 'Yes'
            UseFQDN                   = $false
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_ServerA
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\servera\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        xDFSNamespaceRoot DFSNamespaceRoot_Public_ServerB
        {
            Path                 = "\\$DomainName\Public"
            TargetPath           = '\\serverb\Public'
            Ensure               = 'present'
            Type                 = 'DomainV2'
            Description          = 'Public shared folder'
            PsDscRunAsCredential = $DomainCreds
            DependsOn = '[WindowsFeature]DFSNamespace',
                        '[xSMBShare]Public'
        }

        ForEach ($RootOU in $RootOUs) {
            xDFSNamespaceRoot "DFSNamespaceRoot_ServerA_$RootOU"
            {
                Path                 = "\\$DomainName\$RootOU"
                TargetPath           = "\\servera\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[xSMBShare]Private_$RootOU"
            }

            xDFSNamespaceRoot "DFSNamespaceRoot_ServerB_$RootOU"
            {
                Path                 = "\\$DomainName\$RootOU"
                TargetPath           = "\\serverb\$RootOU"
                Ensure               = 'present'
                Type                 = 'DomainV2'
                Description          = "Private folder for the $RootOU group"
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[xSMBShare]Private_$RootOU"
            }
        }
        

        ###Start DFS Replication configuration###

        xDFSReplicationGroup PublicReplication
        {
            GroupName = 'PublicFiles'
            Description = 'Public files for use by all departments'
            Ensure = 'Present'
            Members = 'servera', 'serverb'
            Folders = 'Public'
            Topology = 'Fullmesh'
            ContentPaths = $publicDirPath
            DomainName = $DomainName
            PSDSCRunAsCredential = $DomainCreds
            DependsOn = '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_ServerA',
                        '[xDFSNamespaceRoot]DFSNamespaceRoot_Public_ServerB'
        }

        ForEach ($RootOU in $RootOUs) {        
        xDFSReplicationGroup "Replication_$RootOU"
            {
                GroupName = "PrivateFiles_$RootOU"
                Description = "Private files for $RootOU"
                Ensure = 'Present'
                Members = 'servera', 'serverb'
                Folders = "$RootOU"
                Topology = 'Fullmesh'
                ContentPaths = "$rootDirPath\$RootOU"
                DomainName = $DomainName
                PSDSCRunAsCredential = $DomainCreds
                DependsOn = "[xDFSNamespaceRoot]DFSNamespaceRoot_ServerA_$RootOU",
                            "[xDFSNamespaceRoot]DFSNamespaceRoot_ServerB_$RootOU"
            }
        }
        
    }
}

$cd = @{
    AllNodes = @(
        @{
            NodeName = 'localhost'
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
    )
}